import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartItems: any = [];
  buyProducts: any;
  orders: any;
  orderDetails: any;
  constructor(public customerService: CustomerService, public router: Router) {
  this.cartItems = this.customerService.cartItems;
   }

  ngOnInit(): void {
   
  }
  purchase() {
    this.customerService.purchase(this.cartItems).subscribe();
    console.log(this.orderDetails);
    this.customerService.getAllProducts().subscribe((result:any=[]) => {console.log(result);this.orderDetails=result;console.log(this.orderDetails);});
   this.customerService.registerOrders(this.orders).subscribe((result : any) =>{ this.orders = result; console.log(result); });
    if(this.orders!=null){
      const orderDetails = {
        orderQuantity : this.buyProducts.productQuantity,
        totalPrice :((this.buyProducts.cropQuantity)*(this.buyProducts.price)),
        product : this.buyProducts,
        orders : this.orders,

        
       };
       console.log("inside payment component" +orderDetails.orderQuantity);
      this.customerService.registerOrderDetails(orderDetails) .subscribe((result : any) =>{ this.orderDetails = result; console.log(result); });
      if(orderDetails!=null){ 
        this.router.navigate(['orders']);
      }
      
      
    }
  }

  deleteRequest(item:any):any{
    this.customerService.deleteReq(item).subscribe((data:any) => {
     const i=this.cartItems.findIndex((record:any) => {
     })
     this.cartItems.splice(i,1);     
     });


 
}
}
