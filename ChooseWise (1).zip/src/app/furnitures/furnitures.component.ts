import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-furnitures',
  templateUrl: './furnitures.component.html',
  styleUrls: ['./furnitures.component.css']
})
export class FurnituresComponent implements OnInit {
  
  furnitures: any
  constructor(private customerService:CustomerService) { }

  ngOnInit(): void {
    this.furnitures = [{productId: 1, productName: 'Brown Sofa Set', description: 'Brown Leather Lavish Sofa Set ', brand: 'Adorn Homez', category: 'Sofas', availability: 'Out of Stock', price: 25999.99,  imagePath: '../../assets/furnitureImages/f1.jpg'},
     {productId: 2, productName: 'Dinning Table  ', description: ' Ravishing Refectory Table ', brand: '4tens', category: 'Tables', availability: 'In Stock', price: 24494.99,
     imagePath: '../../assets/furnitureImages/f2.jpg'},
     {productId: 3, productName: 'Padded Sofa Set ', description: 'Brown wooden frame with Brown fabric padded Sofa set',  brand: 'Kurlon', category: 'Sofas', availability: 'In Stock', price: 29999.99,
     imagePath: '../../assets/furnitureImages/f3.jpg'},
     {productId: 4, productName: 'Circular Table', description: 'Wooden frame table with  Grey Chairs ', brand: 'A J creation', category: 'Tables', availability: 'Out of Stock', price: 17979.98,
     imagePath: '../../assets/furnitureImages/f4.jpg'},
     {productId: 5, productName: 'Ravishing Round Table', description: 'Ravishing  Table ', brand: '12 STARS', category: 'Tables', availability: 'In Stock', price: 22566.99,
     imagePath: '../../assets/furnitureImages/f5.jpg'},
     {productId: 6, productName: 'Kitchen Table', description: 'Light Brown Wooden Kitchen Table',brand: '4tens', category: 'Furniture', availability: 'Out of Stock',  price: 15979.65,
     imagePath: '../../assets/furnitureImages/f6.jpg'},
     {productId: 7, productName: 'Partition Divider', description: 'Handcrafted Wooden Partition  Divider',brand: 'Wooden Crafts', category: 'Furniture', availability: 'In Stock',  price: 21994.99,
     imagePath: '../../assets/furnitureImages/f7.jpg'},
     {productId: 8, productName: 'Chair', description: 'Sky Blue Padded Chair', brand: 'Nilkamal', category: 'chairs', availability: 'Out of Stock', price: 14987.93,
     imagePath: '../../assets/furnitureImages/f8.jpg'},
     {productId: 9, productName: 'Circular Bed', description: 'White & Blue Comfy Circular Sofa', brand: 'Evok', category: 'Sofas', availability: 'In Stock', price: 23456.91,
     imagePath: '../../assets/furnitureImages/f9.jpg',},
    ];
  }

  addToCart(furniture: any) {
    this.customerService.addToCart(furniture);

  }

}
