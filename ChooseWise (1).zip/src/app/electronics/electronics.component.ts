import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-electronics',
  templateUrl: './electronics.component.html',
  styleUrls: ['./electronics.component.css']
})
export class ElectronicsComponent implements OnInit {

  electronics:any
  constructor(public customerService:CustomerService) {

   }

  ngOnInit() {
    this.electronics = [{productId: 1, productName: 'Tv', description: 'Samsung Tv', price: 19999.99, brand:'Samsung', category:'Home Entertainment', availability:'Out of stock', imagePath: '../../assets/electronicImages/e1.jpg'},
     {productId: 2, productName: 'Refrigerator', description: 'Samsung Pro Brand', price: 13499.99, brand:'Samsung', category:'Home Appliances', availability:'In stock', 
     imagePath: '../../assets/electronicImages/e2.jpg'},
     {productId: 3, productName: 'AC', description: 'LG pro band', price: 19999.99, brand:'LG', category:'Air Conditioners', availability:'Out of stock', 
     imagePath: '../../assets/electronicImages/e3.jpg'},
     {productId: 4, productName: 'Mobile', description: 'space gray iPhone 6', price: 23999.99, brand:'Apple', category:'Mobiles', availability:'In stock', 
     imagePath: '../../assets/electronicImages/e4.jpg'},
     {productId: 5, productName: 'Camera', description: 'black DSLR Camera', price: 29999.99, brand:'Canon', category:'Cameras', availability:'Out of stock', 
     imagePath: '../../assets/electronicImages/e5.jpg'},
     {productId: 6, productName: 'Laptop', description: 'MacBook Pro', price: 119999.99, brand:'Apple', category:'Laptops', availability:'In stock', 
     imagePath: '../../assets/electronicImages/e6.jpg'},
     {productId: 7, productName: 'HeadPhones', description: 'white Sony corded headphones', price: 2999.99, brand:'Sony', category:'Headphones', availability:'In stock', 
     imagePath: '../../assets/electronicImages/e7.jpg'},
     {productId: 8, productName: 'Speaker', description: '2g black Amazon Echo speaker on white panel', price: 1999.99, brand:'JBL', category:'Speakers', availability:'Out of stock', 
     imagePath: '../../assets/electronicImages/e8.jpg'},
     {productId: 9, productName: 'Smart Watch', description: 'space gray aluminium Apple Watch', price: 15999.99, brand:'Apple', category:'Smart Bands', availability:'In stock', 
     imagePath: '../../assets/electronicImages/e9.jpg'}
    ];
  }
  addToCart(electronic: any) {
    this.customerService.addToCart(electronic);

  }

  }

