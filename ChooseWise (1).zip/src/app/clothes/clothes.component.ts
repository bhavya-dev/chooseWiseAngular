import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-clothes',
  templateUrl: './clothes.component.html',
  styleUrls: ['./clothes.component.css']
})
export class ClothesComponent implements OnInit {
  clothes:any
  constructor(private customerService:CustomerService) { }

  ngOnInit(): void {
    this.clothes = [{productId: 1, productName: 'Men Blazers', description: ' Dashing Men Blazer ', brand: 'Belario', category:'Blazers', availability:'In stock',
    price: 14568.99,  imagePath: '../../assets/clothImages/c1.jpg'},
     {productId: 2, productName: 'Women Tops ', description: ' Trendy Women Tops', brand: 'sassafras', category:'Tops', availability:'In stock', price: 13499.99,
     imagePath: '../../assets/clothImages/c2.jpg'},
     {productId: 3, productName: 'Casual Women Tops', description: ' Casual Women Tops',brand: '7armoire', category:'Topwear', availability:'Out of stock', price: 12956.45,
     imagePath: '../../assets/clothImages/c3.jpg'},
     {productId: 4, productName: 'Mens T-shirts & Jeans', description: ' Men Jeans and T-shirts',brand: 'Aric', category:'T-shirts', availability:'In stock', price: 15967.99,
     imagePath: '../../assets/clothImages/c4.jpg'},
     {productId: 5, productName: ' Girly Jeans', description: 'Go Girly Jeans with Cool top & Beanie', brand: 'Danbro', category:'Jeans', availability:'In stock',price: 23999.99,
     imagePath: '../../assets/clothImages/c5.jpg'},
     {productId: 6, productName: 'White long Dresses', description: 'White long A-Line Dress',brand: 'Libas', category:'clothing', availability:'In stock', price: 11987.87,
     imagePath: '../../assets/clothImages/c6.jpg'},
     {productId: 7, productName: 'Maxi Dresses', description: 'Cool Girl Long Maxi Dress', brand: 'AJM', category:'Dresses', availability:'Out of stock',price: 13499.99,
     imagePath: '../../assets/clothImages/c7.jpg'},
     {productId: 8, productName: 'Jeggings', description: 'Skinny &Funny Jeggings',brand: 'AADICARE', category:'Bottomwear', availability:'Out of stock', price: 8998.98,
     imagePath: '../../assets/clothImages/c8.jpg'},
     {productId: 9, productName: 'Women Floral Tops', description: 'Floral Tops', brand: 'AAHIL', category:'Topwear', availability:'In stock', price: 5678.99,
     imagePath: '../../assets/clothImages/c9.jpg'}
    ];
  }
  addToCart(cloth: any) {
    this.customerService.addToCart(cloth);


  }


  }


