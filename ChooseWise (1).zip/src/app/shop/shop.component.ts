import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {

  constructor(public customerService:CustomerService,public config: NgbCarouselConfig) { 
      config.interval=2000;
      config.wrap=true;
      config.keyboard=false;
      config.pauseOnHover=false;
  }

  ngOnInit(): void {
  }

}
