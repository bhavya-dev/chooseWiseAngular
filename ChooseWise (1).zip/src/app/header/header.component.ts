import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  electronics: any = [];
  constructor(public customerService:CustomerService) { 
    
  }

  ngOnInit() {
    this.customerService.getForCart().subscribe(result => this.electronics.push(result));
  }

}

