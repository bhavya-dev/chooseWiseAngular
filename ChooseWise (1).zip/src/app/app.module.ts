import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';

import { AuthGuard } from './auth.guard';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomerService } from './customer.service';
import { ShopComponent } from './shop/shop.component';
import { RentComponent } from './rent/rent.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { FurnituresComponent } from './furnitures/furnitures.component';
import { ClothesComponent } from './clothes/clothes.component';
import { CartComponent } from './cart/cart.component';
import { ToastrModule } from 'ngx-toastr';

 
const appRoot: Routes = [{path: 'home',component: HomeComponent},
{path: 'login',component:LoginComponent},
{path: 'shop',component:ShopComponent},
{path: 'rent',component:RentComponent},
{path: 'register', component: RegisterComponent},
{path: 'electronics',component:ElectronicsComponent},
{path: 'furnitures',component:FurnituresComponent},
{path: 'clothes',component:ClothesComponent},
{path: 'cart', component:CartComponent}

];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HeaderComponent,
    HomeComponent,
    ShopComponent,
    RentComponent,
    ElectronicsComponent,
    FurnituresComponent,
    ClothesComponent,
    CartComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    NgbModule,
    RouterModule.forRoot(appRoot),
    HttpClientModule,
    ToastrModule.forRoot()

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }