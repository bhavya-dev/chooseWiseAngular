import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Router}from '@angular/router';
import { Observable, Subject } from 'rxjs';
import {map, retry} from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  cartItems: any = [];
  productToBeAdded: Subject<any>;
  userLogged: boolean;


  constructor(public httpClient: HttpClient,public router:Router) { 
    this.userLogged=false;
    this.productToBeAdded = new Subject();
  }

  addToCart(electronic: any) {
    this.productToBeAdded.next(electronic);

    this.cartItems.push(electronic);
  }

  getForCart(){
    return this.productToBeAdded.asObservable();
  }

  public setUserLoggedIn(): void{
    this.userLogged=true;
  }
  public setUserLoggedOut(): void{
    this.userLogged=false;
    this.router.navigate(['login']);
  }
  public getUserLogged():any{
    return this.userLogged;
  }
  getAllCustomers(): any {
    return this.httpClient.get('getAllCustomers');
  }

  getCustomerById(customerId: any): any {
    return this.httpClient.get('getCustomerById/' + customerId);
  }

  register(regForm: any): any {
    console.log(regForm);
    return this.httpClient.post("register/",regForm);
  }
  loginAuthentication(loginId: any,password :any):any{

    return this.httpClient.get('getCustomerByLoginId/' +loginId +'/'+ password);

  }
  getAllProducts():any{
     return this.httpClient.get('getAllProducts/').pipe();
  }
  purchase(items: any) {
    return this.httpClient.post('purchase/', items);
  }
  registerOrders(orders : any):any{
    return this.httpClient.post('registerOrders/', orders);
  }

  registerOrderDetails(orderDetails : any):any{
    console.log("registerOrderDetails " +orderDetails.orderQuantity);

    return this.httpClient.post('registerOrderDetails/', orderDetails);
    
  }
  deleteReq(item: any):any {
    return this.httpClient.post('deleteReq/',item);
  }

}
