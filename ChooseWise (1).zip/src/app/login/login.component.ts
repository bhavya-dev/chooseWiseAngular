import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { ToastrService } from 'ngx-toastr';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  customer: any;
  constructor(public toastr:ToastrService, public router:Router,public customerService: CustomerService) { 
    this.customer = {loginId:'', password:''};
  }

  ngOnInit() {
  }
 
 async submitLoginForm(loginForm: any){

   console.log(loginForm);
   if(loginForm.loginId==='admin'&&loginForm.password==='admin'){
     this.customerService.setUserLoggedIn();
    console.log(loginForm);
   }
   else{
    await this.customerService.loginAuthentication(loginForm.loginId,loginForm.password).toPromise().then((data:any)=>{this.customer=data;console.log(data);});
     if(this.customer.loginId){
      
       this.customerService.setUserLoggedIn();
       this.toastr.success('Login Success');
      this.router.navigate(['home']);
     }
     else{
      this.toastr.error('Invalid Login');
       this.router.navigate(['register']);

     }
    }

  
  }

 
  
}
